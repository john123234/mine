#!/bin/sh
./miner --algo ethash --server prohashing.com:3339 --user hashmining123 --pass l=15,n=a