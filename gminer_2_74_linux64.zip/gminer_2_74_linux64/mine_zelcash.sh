#!/bin/sh
./miner --algo 125_4 --server zel.2miners.com:9090 --user t1NKFhdtaeazcgDWXaMCCVG3k2exkLp9R31 --pass x
