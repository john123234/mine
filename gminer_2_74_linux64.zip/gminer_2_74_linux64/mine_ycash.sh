#!/bin/sh
./miner --algo 192_7 --pers ZcashPoW --server ycash.dapool.io:3344 --user s1ZpDP65RjYqNpRRnP5DB9fSsUJEpQKJDNj --pass x
